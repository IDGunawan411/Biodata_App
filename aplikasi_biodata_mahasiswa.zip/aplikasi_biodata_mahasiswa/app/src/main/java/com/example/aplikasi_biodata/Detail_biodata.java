package com.example.aplikasi_biodata;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class Detail_biodata extends AppCompatActivity {

    @BindView(R.id.detail_nama)
    EditText etNama;
    @BindView(R.id.detail_kelas)
    EditText etKelas;
    @BindView(R.id.detail_alamat)
    EditText etAlamat;
    @BindView(R.id.detail_nomor)
    EditText etNomor;
//    @BindView(R.id.rg_detail_kelamin)
//    RadioButton etKelamin;

    @BindView(R.id.rb_detail_laki) RadioButton rb_laki;
    @BindView(R.id.rb_detail_perempuan) RadioButton rb_perempuan;

    @BindView(R.id.rg_detail_kelamin)
    RadioGroup rg_kelamin;

    @BindView(R.id.bt_update)
    Button btUpdate;
    @BindView(R.id.bt_hapus)
    Button btHapus;

    private int posisi;

    ArrayList<Biodata> catatanArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_biodata);
        ButterKnife.bind(this);

        getSupportActionBar().setTitle("Update Biodata"); // for set actionbar title
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // for add back arrow in action bar

        //tangkap bundle
        Bundle bundle = null;
        bundle = this.getIntent().getExtras();
        etNama.setText(bundle.getString("b_nama"));
        etKelas.setText(bundle.getString("b_kelas"));

        //pada radio button
        if ("b_kelamin" == "Laki - Laki"){
            rb_laki.setChecked(true);
        }else{
            rb_perempuan.setChecked(false);
        }

        etAlamat.setText(bundle.getString("b_alamat"));
        etNomor.setText(bundle.getString("b_nomor"));
        posisi = bundle.getInt("posisi");

        btUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama, kelas, kelamin, alamat, nomor;
                RadioButton mrb_kelamin;
                //pilih radio button yang ada di radio button group
                int selectedId = rg_kelamin.getCheckedRadioButtonId();
                //khusus ini ga pake butter knife, karena nilai yang dimasukkan dinamis berdasarkan ID yang dipilih
                mrb_kelamin = (RadioButton) findViewById(selectedId);

                nama = etNama.getText().toString();
                kelas = etKelas.getText().toString();
                kelamin = mrb_kelamin.getText().toString();
                alamat = etAlamat.getText().toString();
                nomor = etNomor.getText().toString();

                catatanArrayList.set(posisi, new Biodata(nama, kelas, kelamin, alamat, nomor));
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = prefs.edit();
                Gson gson = new Gson();
                String json = gson.toJson(catatanArrayList);
                editor.putString("sp_list_biodata", json);
                editor.apply();

                Intent intent = new Intent( v.getContext(), MainActivity.class);
                v.getContext().startActivity(intent);
            }
        });

        btHapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                catatanArrayList.remove(posisi);
                //simpan kedalam shared preferences
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = prefs.edit();
                Gson gson = new Gson();
                String json = gson.toJson(catatanArrayList);
                editor.putString("sp_list_biodata", json);
                editor.apply();

                Intent intent = new Intent( v.getContext(), MainActivity.class);
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        //load data dari shared preferences
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        Gson gson = new Gson();
        String json = prefs.getString("sp_list_biodata", "");
        Type type = new TypeToken<ArrayList<Biodata>>() {}.getType();


        if (json != "") {
            catatanArrayList =  gson.fromJson(json, type);
        }

    }

}
