package com.example.aplikasi_biodata;

public class Biodata {
    String nama, kelas,kelamin, alamat, nomor;

    public Biodata(String nama, String kelas,String kelamin, String alamat, String nomor) {
        this.nama = nama;
        this.kelas = kelas;
        this.kelamin = kelamin;
        this.alamat = alamat;
        this.nomor = nomor;
    }

    public String getNama() {
        return nama;
    }
    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getKelas() {
        return kelas;
    }
    public void setKelas(String kelas) {
        this.kelas = kelas;
    }

    public String getKelamin() {
        return kelamin;
    } public void setKelamin(String kelamin) {
        this.kelamin = kelamin;
    }

    public String getAlamat() {
        return alamat;
    }
    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNomor() {
        return nomor;
    }
    public void setNomor(String nomor) {
        this.nomor = nomor;
    }

}

