package com.example.aplikasi_biodata;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class Create_biodata extends DialogFragment {
    @BindView(R.id.et_nama)
    EditText met_nama;
    @BindView(R.id.et_kelas)
    EditText met_kelas;
    @BindView(R.id.et_alamat)
    EditText met_alamat;
    @BindView(R.id.et_nomor)
    EditText met_nomor;
    @BindView(R.id.rg_kelamin)
    RadioGroup mrg_kelamin;


    Unbinder unbinder;
    RecyclerView rvObject;
    Activity activity;
    private ArrayList<Biodata> biodataArrayList = new ArrayList<>();

    public Create_biodata(RecyclerView rvObject, Activity activity, ArrayList<Biodata> biodataArrayList) {
        this.rvObject = rvObject;
        this.activity = activity;
        if(biodataArrayList != null){
            this.biodataArrayList = biodataArrayList;
        }

    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new AlertDialog.Builder(getActivity())
                .setView(R.layout.form_input_biodata)
                .setPositiveButton("SIMPAN", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String nama, kelas, kelamin, alamat, nomor;
                        RadioButton mrb_kelamin;
                        //pilih radio button yang ada di radio button group
                        int selectedId = mrg_kelamin.getCheckedRadioButtonId();

                        //khusus ini ga pake butter knife, karena nilai yang dimasukkan dinamis berdasarkan ID yang dipilih
                        mrb_kelamin = (RadioButton) getDialog().findViewById(selectedId);


                        nama = String.valueOf(met_nama.getText());
                        kelas = String.valueOf(met_kelas.getText());
                        kelamin = mrb_kelamin.getText().toString();
                        alamat = String.valueOf(met_alamat.getText());
                        nomor = String.valueOf(met_nomor.getText());

                        biodataArrayList.add(
                                new Biodata( nama, kelas, kelamin, alamat, nomor)
                        );

                        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(activity.getApplicationContext());
                        SharedPreferences.Editor editor = prefs.edit();
                        Gson gson = new Gson();
                        String json = gson.toJson(biodataArrayList);
                        editor.putString("sp_list_biodata", json);
                        editor.apply();

                        Toast.makeText(getActivity(),
                                nama + " berhasil disimpan",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("BATAL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create();
    }

    @Override
    public void onStart() {
        super.onStart();
        unbinder = ButterKnife.bind(this, getDialog()); //bind butter knife ( caranya begini kalo di dialog fragment )
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind(); //kalo udah di bind, harus di "UNBIND / DILEPAS" better knife-nya
    }

}
