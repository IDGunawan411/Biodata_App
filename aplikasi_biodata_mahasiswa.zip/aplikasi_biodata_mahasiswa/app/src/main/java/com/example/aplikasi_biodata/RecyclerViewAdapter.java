package com.example.aplikasi_biodata;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.CategoryViewHolder> {
    Context context;
    ArrayList<Biodata> biodataArrayList;
    Activity activity;

    public RecyclerViewAdapter(Context context, ArrayList<Biodata> biodataArrayList, Activity activity) {
        this.context = context;
        this.biodataArrayList = biodataArrayList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public RecyclerViewAdapter.CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemRow = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout, parent, false);
        return new CategoryViewHolder(itemRow);
    }

    @Override
    public int getItemCount() {
        return biodataArrayList.size();
    }

    public class CategoryViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.tv_nama)
        TextView tv_nama;
        @BindView(R.id.tv_kelas)
        TextView tv_kelas;

        @BindView(R.id.tv_kelamin)
        TextView tv_kelamin;

        @BindView(R.id.tv_alamat)
        TextView tv_alamat;
        @BindView(R.id.tv_nomor)
        TextView tv_nomor;


        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.CategoryViewHolder holder, int position) {
        final String
                nama = biodataArrayList.get(position).getNama(),
                kelas = biodataArrayList.get(position).getKelas(),
                kelamin = biodataArrayList.get(position).getKelamin(),
                alamat = biodataArrayList.get(position).getAlamat(),
                nomor = biodataArrayList.get(position).getNomor();


        holder.tv_nama.setText(nama);
        holder.tv_kelas.setText(kelas);
        holder.tv_kelamin.setText(kelamin);
        holder.tv_alamat.setText(alamat);
        holder.tv_nomor.setText(nomor);

        Bundle b = new Bundle();
        b.putString("b_nama", nama);
        b.putString("b_kelas", kelas);
        b.putString("b_kelamin", kelamin);
        b.putString("b_alamat", alamat);
        b.putString("b_nomor", nomor);


        b.putInt("posisi", position);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(v.getContext())
                        .setTitle(nama + " " + kelas)
                        .setCancelable(true)
                        .setNegativeButton("Hapus", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                biodataArrayList.remove(position);
                                notifyDataSetChanged();
                                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(activity.getApplicationContext());
                                SharedPreferences.Editor editor = prefs.edit();
                                Gson gson = new Gson();
                                String json = gson.toJson(biodataArrayList);
                                editor.putString("sp_list_biodata", json);
                                editor.apply();
                            }
                        })
                        .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent( v.getContext(), Detail_biodata.class);
                                intent.putExtras(b);
                                v.getContext().startActivity(intent);
                            }
                        })
                        .setNeutralButton("Tutup", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .show();
            }
        });
    }


}