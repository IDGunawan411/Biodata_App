package com.example.aplikasi_biodata;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class Biodata_Mahasiswa extends Fragment {

    @BindView(R.id.rv_container)
    RecyclerView rv;

    ArrayList<Biodata> biodataList = new ArrayList<>();

    @OnClick(R.id.tambah) void set(){
        FragmentManager fm = getActivity().getSupportFragmentManager();
        Create_biodata createAbsen = new Create_biodata(rv, getActivity(), biodataList);
        createAbsen.show(fm, "Biodata");

    }

    private Unbinder unbinder;

    @Override public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v =  inflater.inflate(R.layout.fragment_biodata, container, false);
        unbinder = ButterKnife.bind(this, v);
        showRecyclerView();
        getData();
        getActivity().setTitle("Biodata Mahasiswa");
        return v;
    }

    public void showRecyclerView() {
        rv.setLayoutManager((new LinearLayoutManager(getContext())));
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(getContext(), biodataList, getActivity());
        rv.setAdapter(adapter);
    }

    private void getData() {
        //load data dari shared preferences
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getContext());
        Gson gson = new Gson();
        String json = prefs.getString("sp_list_biodata", "");
        Type type = new TypeToken<ArrayList<Biodata>>() {}.getType();


        if (json != "") {
            biodataList =  gson.fromJson(json, type);
            if ( biodataList.size() > 0 ) showRecyclerView();
        }
    }




}
